#!/usr/bin/env python3
"""Generate launcher icon PNGs for the HesGoal Android app."""
from PIL import Image, ImageDraw
import os

BASE = "/home/z/my-project/download/HesGoal-WebView-App/app/src/main/res"

SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

def create_icon(size, path):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Dark background circle
    margin = int(size * 0.08)
    draw.ellipse([margin, margin, size - margin, size - margin],
                 fill=(26, 26, 46, 255))

    # Green diamond shape
    cx, cy = size // 2, size // 2
    r = int(size * 0.25)
    diamond = [
        (cx, cy - r),   # top
        (cx + r, cy),   # right
        (cx, cy + r),   # bottom
        (cx - r, cy),   # left
    ]
    draw.polygon(diamond, fill=(0, 230, 118, 255))

    # White "play" arrow in center
    ar = int(size * 0.12)
    arrow = [
        (cx - ar // 2, cy - ar),
        (cx + ar, cy),
        (cx - ar // 2, cy + ar),
    ]
    draw.polygon(arrow, fill=(255, 255, 255, 255))

    img.save(path)

for folder, size in SIZES.items():
    dir_path = os.path.join(BASE, folder)
    os.makedirs(dir_path, exist_ok=True)
    create_icon(size, os.path.join(dir_path, "ic_launcher.png"))
    create_icon(size, os.path.join(dir_path, "ic_launcher_round.png"))
    print(f"Created {folder}/ic_launcher.png ({size}x{size})")

print("All icons generated!")
